//
//  ThirdViewController.swift
//  button
//
//  Created by Jennifer Wasson on 7/21/17.
//  Copyright © 2017 Jennifer Wasson. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController, UITextFieldDelegate, UIPickerViewDataSource, UIPickerViewDelegate {
    
    
    @IBOutlet weak var subView3: UIView!
    
    var model = Model()
    
    @IBOutlet weak var StepperLabel: UILabel!
    @IBOutlet weak var classNameText: UITextField!
    
    @IBOutlet weak var gradeLabel: UILabel!
    
    
    @IBOutlet weak var pickerView3: UIPickerView!
     var gradeList = ["A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F","FN"]
    
    
    
    
    @IBAction func LetterGradeButton(_ sender: UIButton) {
        
        subView3.isHidden = false
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    
    @IBAction func NextButton(_ sender: UIButton) {
        
        var grades: Grades
        
        //remove row that is being edited and add everything to user defaults again
        if Model.gradesArray.isEmpty == false {
        if FourthViewController.edit == true{
            Model.gradesArray.remove(at: FourthViewController.myIndex)
             UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
            
            if Model.gradesArray.isEmpty == false {
            for index in 0...Model.gradesArray.count-1{
                grades = Grades(className: Model.gradesArray[index].className, gradePoints: Model.gradesArray[index].gradePoints, expectedGrade: Model.gradesArray[index].expectedGrade, creditHours: Model.gradesArray[index].creditHours)
                Model.addtoUserDefaults(grade: grades)
                } } }

        }
        
                let gradepoints = Model.calculateGradePoints(creditHours: StepperLabel.text!, Grade: gradeLabel.text!)
        let credithours = Double(StepperLabel.text!)
        grades = Grades(className: classNameText.text!, gradePoints: gradepoints, expectedGrade: gradeLabel.text!, creditHours: credithours!)
        //print(gradepoints)
        if (gradeLabel.text! != "") && (classNameText.text != ""){
            Model.addtoUserDefaults(grade: grades)
        Model.gradesArray.append(grades)}
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        classNameText.resignFirstResponder()
        
        
        return (true)
    }
    
    @IBAction func hoursStepper(_ sender: UIStepper) {
        
        StepperLabel.text = String(sender.value)
    }
    
   // func textFieldDidEndEditing(_ textField: UITextField) {
        
       // if textField == classNameText{
          //  model.
      //  }
   // }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        
        
        
            return gradeList[row]
        
        
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
       
            return gradeList.count
        }
    
    
    
    
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let label = (view as? UILabel) ?? UILabel()
        label.font = UIFont(name: "Gils Sans", size: 15)
        
        //label.textColor = .blue
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 15)
        label.text = ""
        
        
        
            
        label.text = gradeList[row]
        
        
        return label
        
    }
    
    
    
    
    
    
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        
       subView3.isHidden = true
        gradeLabel.text = gradeList[row]
        
        
        
    }

    override func viewDidLoad() {
        
        StepperLabel.text = "3.0"
        self.classNameText.delegate = self
        super.viewDidLoad()
        subView3.isHidden = true
        if Model.gradesArray.isEmpty == false{
        if FourthViewController.edit == true{
            classNameText.text = Model.gradesArray[FourthViewController.myIndex].className
            StepperLabel.text = String(Model.gradesArray[FourthViewController.myIndex].creditHours)
            gradeLabel.text = Model.gradesArray[FourthViewController.myIndex].expectedGrade
            } }

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   

}
