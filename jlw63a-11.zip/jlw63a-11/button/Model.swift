//
//  Model.swift
//  button
//
//  Created by Jennifer Wasson on 7/20/17.
//  Copyright © 2017 Jennifer Wasson. All rights reserved.
//

import Foundation

struct Grades{
    var className:  String
    var gradePoints:  Double
    var expectedGrade:  String
    var creditHours: Double
}



class Model {
    
  static  var hoursTaken = 0.0
    static var currentGPA = 0.0
    static var gradesArray =  [Grades]()
    //static var ProjectedGPA = 0.0
  
    
    static func calculateGradePoints(creditHours:  String, Grade: String) -> Double{
        
        
        switch Grade {
           case "A": return(4.0*Double(creditHours)!)
            case "A-": return(3.7*Double(creditHours)!)
           case "B+":  return(3.3*Double(creditHours)!)
            case "B":  return(3.0*Double(creditHours)!)
           case "B-":  return(2.7*Double(creditHours)!)
            case "C+": return(2.3*Double(creditHours)!)
            case "C":  return(2.0*Double(creditHours)!)
            case "C-":  return(1.7*Double(creditHours)!)
            case "D+":  return(1.3*Double(creditHours)!)
            case "D":  return(1.0*Double(creditHours)!)
           case "D-": return(0.7*Double(creditHours)!)
           case "F":  return 0.0
            case "FN":  return 0.0
            
       default: return 0.0
        }
    //return 0.0
    }
    static func ProjectedGPA() -> Double{
        let currentGradePoints = currentGPA * hoursTaken
        var totalProjectedHours = 0.0
        var totalProjectedGradePoints = 0.0
        for grades in gradesArray{
           totalProjectedHours = totalProjectedHours + grades.creditHours
            totalProjectedGradePoints = totalProjectedGradePoints + grades.gradePoints
        }
        let unRoundedGPA = (currentGradePoints + totalProjectedGradePoints)/(totalProjectedHours + hoursTaken)
        //print(unRoundedGPA)
        
        return (Double(round(10*unRoundedGPA)/10))
    }
    
    static func ProjectedGPASubstitute(OldLetterGrade: String, NewLetterGrade: String, creditHours: String) -> Double{
        
        let currentGradePoints = currentGPA * hoursTaken
        let OldGradePoints = calculateGradePoints(creditHours: creditHours, Grade: OldLetterGrade)
        
        var NewGradePoints =  calculateGradePoints(creditHours: creditHours, Grade: NewLetterGrade)
        let RemainingGradePoints = currentGradePoints - OldGradePoints
        NewGradePoints = NewGradePoints + RemainingGradePoints
        let unRoundedGPA = NewGradePoints/hoursTaken
        print(unRoundedGPA)
        
        return (Double(round(10*unRoundedGPA)/10))
    

        
    }
    static func LoadGradesArray(){
        var gradePointsArray = [Double]()
        var expectedGrade = [String]()
        var className = [String]()
        var hoursArray = [Double]()
        var grade:  Grades
        
        
        //UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
        
        if let gradepoints = UserDefaults.standard.object(forKey:  "gradepoints"){
            //print(gradepoints)
            gradePointsArray = gradepoints as! [Double] }
        //gradePointsArray.append(Double(round(10*3.2)/10))
        
        if let expectedgrade = UserDefaults.standard.object(forKey:  "expectedgrade"){
            //print(expectedgrade)
            expectedGrade = expectedgrade as! [String] }
            //expectedGrade.append("A")
        
        if let classname = UserDefaults.standard.object(forKey:  "classname"){
           // print(classname)
            className = classname as! [String] }
           //className.append("Chemistry")
        
        if let hours = UserDefaults.standard.object(forKey:  "hours"){
         //   print(hours)
            hoursArray = hours as! [Double] }
            hoursArray.append(4.0)
        //print(gradePointsArray.count)
        if(gradePointsArray.isEmpty == false) {
        
        for index in 0...gradePointsArray.count-1 {
            //print(index)
            grade = Grades(className: className[index], gradePoints: gradePointsArray[index], expectedGrade: expectedGrade[index], creditHours: hoursArray[index])
            Model.gradesArray.append(grade)
          //  print(Model.gradesArray)
            
        }
        }
 
    }
    
    static func addtoUserDefaults(grade:  Grades)
    {
        
        var gradePointsArray = [Double]()
        var expectedGrade = [String]()
        var className = [String]()
        var hoursArray = [Double]()
        
        //UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
        
        if let gradepoints = UserDefaults.standard.object(forKey:  "gradepoints"){
            //print(gradepoints)
            gradePointsArray = gradepoints as! [Double] }
    
        
        if let expectedgrade = UserDefaults.standard.object(forKey:  "expectedgrade"){
            //print(expectedgrade)
            expectedGrade = expectedgrade as! [String] }
        
        
        if let classname = UserDefaults.standard.object(forKey:  "classname"){
            //print(classname)
            className = classname as! [String] }
        
        
        if let hours = UserDefaults.standard.object(forKey:  "hours"){
            //print(hours)
            hoursArray = hours as! [Double] }
        
        //print(gradePointsArray.count)
       
      
        
        gradePointsArray.append(grade.gradePoints)
        expectedGrade.append(grade.expectedGrade)
        className.append(grade.className)
        hoursArray.append(grade.creditHours)
        print(hoursArray.count)
        
        UserDefaults.standard.set(gradePointsArray, forKey: "gradepoints")
        UserDefaults.standard.synchronize()
        
        UserDefaults.standard.set(expectedGrade, forKey: "expectedgrade")
        UserDefaults.standard.synchronize()
        
        UserDefaults.standard.set(className, forKey: "classname")
        UserDefaults.standard.synchronize()
        
        UserDefaults.standard.set(hoursArray, forKey: "hours")
        UserDefaults.standard.synchronize()
    }
    

}
