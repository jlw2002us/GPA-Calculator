//
//  SeventhViewController.swift
//  button
//
//  Created by Jennifer Wasson on 8/1/17.
//  Copyright © 2017 Jennifer Wasson. All rights reserved.
//

import UIKit

class SeventhViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    
    @IBOutlet weak var subView2: UIView!
    
    var desiredGPA = 0.0
    
      @IBOutlet weak var GPALabel: UILabel!

    @IBOutlet weak var projectedGPALabel: UILabel!
    
    
    @IBOutlet weak var PickerView2: UIPickerView!
    
    @IBOutlet weak var SubView: UIView!
    
    let choices2 = ["2.0","2.1","2.2","2.3","2.4","2.5","2.6","2.7","2.8","2.9","3.0","3.1","3.2","3.3","3.4","3.5","3.6","3.7","3.8","3.9","4.0"]
    
    
    let choices: [String] = (1...90).map {  String($0)}
    
    
    @IBOutlet weak var PickerView1: UIPickerView!
    @IBOutlet weak var hoursLabel: UILabel!
    
    @IBAction func calculateButton(_ sender: UIButton) {
        
        if(hoursLabel.text != "") && (GPALabel.text != "") {
            let newGradePoints = ((Model.hoursTaken + Double(hoursLabel.text!)!) * desiredGPA) - (Model.currentGPA*Model.hoursTaken)
            var NewGPA = newGradePoints/Double(hoursLabel.text!)!
            print(NewGPA)
            //print(newGradePoints)
            NewGPA = (Double(round(10*NewGPA)/10))
            print(NewGPA)
            if (Model.currentGPA != 0.0) && (Model.hoursTaken != 0.0){
                
                
                if (NewGPA > 4.0) || (desiredGPA < Model.currentGPA) {
                    projectedGPALabel.text = "Try again"
                }
                else {
                    projectedGPALabel.text = "The GPA needed is \(NewGPA)"
                    print(projectedGPALabel.text!) }
                
                
            }
            else {
                //projectedGPALabel.text = "Please go back and enter current GPA and hours"
            }
    }
    }
    
    @IBAction func hoursButton(_ sender: UIButton) {
        subView2.isHidden = false
    }
    
   
    
    @IBAction func GPAButton(_ sender: UIButton) {
        SubView.isHidden = false
        
    }
    
   
    
    
    
    
    
  
  
  
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        
        if pickerView.tag == 1 {
            return choices2[row]}
        else if row  <  55 {
            return choices[row]
        }
        return ""
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView.tag == 1{
            print(choices2.count)
            return choices2.count}
        else{
            return choices.count
        }
    }
    
    
    
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let label = (view as? UILabel) ?? UILabel()
        label.font = UIFont(name: "Gils Sans", size: 15)
        
        //label.textColor = .blue
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 15)
        label.text = ""
        if pickerView.tag == 1{
            label.text = choices2[row]}
        else if row < 55 {
            
            label.text = choices[row]
        }
        
        return label
        
    }
    
    
    
    
    
    
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        
        
        if pickerView.tag  ==  1 {
            
            
            desiredGPA = Double(choices2[row])!
            //print(desiredGPA!)
            GPALabel.text = choices2[row]
            
            
            
           
        }
        else if row < 55 {
            let hours = Double(choices[row])
            
        print(hours!)
            hoursLabel.text = choices[row]
            
        
        //count = 1
       
        
        
        
    }
        
        SubView.isHidden = true
        subView2.isHidden = true
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        SubView.isHidden = true
        subView2.isHidden = true
      
        
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
