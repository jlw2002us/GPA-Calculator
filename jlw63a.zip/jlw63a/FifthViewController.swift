//
//  FifthViewController.swift
//  button
//
//  Created by Jennifer Wasson on 7/22/17.
//  Copyright © 2017 Jennifer Wasson. All rights reserved.
//

import UIKit

class FifthViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    
    
  
    
    
    @IBOutlet weak var StepperLabel: UILabel!
   
    
  
    
    
    @IBOutlet weak var GradeLabel2: UILabel!
    
    static var hours:  String = " "
    static var letterGrade:  String = " "
    var gradeList2 = ["C-","D+","D","D-","F","FN"]
    
   
    
    
    @IBOutlet weak var SubView5: UIView!
    
    
    @IBOutlet weak var PickerView1: UIPickerView!
   
    
    
    @IBAction func GradeButton(_ sender: UIButton) {
        
        SubView5.isHidden = false
        
        
    }
    
    
    @IBAction func NextButton(_ sender: UIButton) {
        
        print(StepperLabel.text!)
        
        FifthViewController.hours = StepperLabel.text!
        
        
        FifthViewController.letterGrade = GradeLabel2.text!
        

        
        
    }
    
    
    @IBAction func StepperButton(_ sender: UIStepper) {
        
           StepperLabel.text = String(sender.value)
        //FifthViewController.hours = StepperLabel.text!
    }
    
    
    
    

    

    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
       
        
            return gradeList2[row]
        
        
        
        
        
        
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        
            return gradeList2.count
        
    }
    
    
    
    
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let label = (view as? UILabel) ?? UILabel()
        label.font = UIFont(name: "Gils Sans", size: 15)
        
        //label.textColor = .blue
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 15)
        label.text = ""
        
        
        
       
            label.text = gradeList2[row]
        
        
        
        return label
        
    }
    
    
    
    
    
    
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
       
        
            GradeLabel2.text = gradeList2[row]
            SubView5.isHidden = true
        
        
        
        
    }
    

  
    override func viewDidLoad() {
        
        StepperLabel.text = "3.0"
        super.viewDidLoad()
        
        SubView5.isHidden = true

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

  

}
