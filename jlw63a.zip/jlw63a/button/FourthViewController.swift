//
//  FourthViewController.swift
//  button
//
//  Created by Jennifer Wasson on 7/21/17.
//  Copyright © 2017 Jennifer Wasson. All rights reserved.
//

import UIKit


class FourthViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var TableView: UITableView!
    
    var thirdviewcontroller = ThirdViewController()
    static var edit = false
    static var myIndex = 0
    @IBAction func backButton(_ sender: UIButton) {
    }
    
    @IBOutlet weak var CalculatedGPALabel: UILabel!
    
    
    
    @IBAction func editButton(_ sender: Any) {
        
        FourthViewController.edit = true
        
        
    }
    
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            FourthViewController.edit = false
           // print(FourthViewController.edit)
            
            return Model.gradesArray.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            guard
                let cell = tableView.dequeueReusableCell(withIdentifier: "cell",
                                                         for: indexPath) as? ViewControllerTableViewCell
                
            
                
                
                else {  return UITableViewCell() }
            
            
            cell.classNameLabel.text = Model.gradesArray[indexPath.row].className
            cell.hoursLabel.text =  String(Model.gradesArray[indexPath.row].creditHours)
            cell.GradeLabel.text = Model.gradesArray[indexPath.row].expectedGrade
            cell.GradePointsLabel.text =  String(Model.gradesArray[indexPath.row].gradePoints)

            

            
            
            return cell
        
        
    }
    
   
    @IBAction func SubstituteButton(_ sender: UIButton) {
        
    }
    
     func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        var grades:  Grades
        if editingStyle == UITableViewCellEditingStyle.delete {
            Model.gradesArray.remove(at: indexPath.row)
            
            UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
            if Model.gradesArray.isEmpty == false {
            for index in 0...Model.gradesArray.count-1{
                grades = Grades(className: Model.gradesArray[index].className, gradePoints: Model.gradesArray[index].gradePoints, expectedGrade: Model.gradesArray[index].expectedGrade, creditHours: Model.gradesArray[index].creditHours)
                Model.addtoUserDefaults(grade: grades)
                } }
            if Model.gradesArray.isEmpty == false {
                CalculatedGPALabel.text = "Your Projected GPA is \(Model.ProjectedGPA())"}
            else{
                CalculatedGPALabel.text = ""
            }
            tableView.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        FourthViewController.myIndex = indexPath.row
        
    }
    
   
    

    override func viewDidLoad() {
        
        //print(Model.ProjectedGPA())
        super.viewDidLoad()
        if Model.gradesArray.isEmpty == false {
        CalculatedGPALabel.text = "Your Projected GPA is \(Model.ProjectedGPA())"}

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
