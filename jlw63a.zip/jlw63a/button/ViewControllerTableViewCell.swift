//
//  ViewControllerTableViewCell.swift
//  button
//
//  Created by Jennifer Wasson on 7/21/17.
//  Copyright © 2017 Jennifer Wasson. All rights reserved.
//

import UIKit

class ViewControllerTableViewCell: UITableViewCell {
    
    @IBOutlet weak var GradePointsLabel: UILabel!
    @IBOutlet weak var hoursLabel: UILabel!
    
    @IBOutlet weak var classNameLabel: UILabel!
    
    @IBOutlet weak var GradeLabel: UILabel!
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
