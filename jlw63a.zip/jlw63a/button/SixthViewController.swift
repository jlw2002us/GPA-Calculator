//
//  SixthViewController.swift
//  button
//
//  Created by Jennifer Wasson on 7/24/17.
//  Copyright © 2017 Jennifer Wasson. All rights reserved.
//

import UIKit

class SixthViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    
    
    @IBOutlet weak var ProjectedGPALabel: UILabel!
    @IBOutlet weak var pickerView: UIPickerView!
    
    
    
    
    @IBOutlet weak var subView: UIView!
    
    @IBOutlet weak var LetterGrade: UILabel!
    
    var gradeList2 = ["A","A-","B+","B","B-","C+","C","C-","D+","D","D-","F","FN"]
    
    
    

    @IBAction func LetterGrade(_ sender: UIButton) {
        subView.isHidden = false
        
    }
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        
        
        return gradeList2[row]
        
        
        
        
        
        
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        
        return gradeList2.count
        
    }
    
    
   
    @IBAction func AddButton(_ sender: Any) {
        
            if SecondViewController.SubstituteBool == true {
                if (FifthViewController.letterGrade != "") {
                    if LetterGrade.text != ""{
                        let ProjectedGPA = Model.ProjectedGPASubstitute(OldLetterGrade: FifthViewController.letterGrade, NewLetterGrade: LetterGrade.text!, creditHours: FifthViewController.hours)
                        ProjectedGPALabel.text = "Your Projected GPA is \(ProjectedGPA)"
                        print(ProjectedGPA) }
                }
            }
            
        
        
        
        
        
        
        
        
        
    }
    
    
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let label = (view as? UILabel) ?? UILabel()
        label.font = UIFont(name: "Gil Sans", size: 15)
        
        //label.textColor = .blue
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 15)
        label.text = ""
        
        
        
        
        label.text = gradeList2[row]
        
        
        
        return label
        
    }
    
    
    
    
    
    
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        
        
        LetterGrade.text = gradeList2[row]
        subView.isHidden = true
        
        
        
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        subView.isHidden = true

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
