//
//  ViewController.swift
//  button
//
//  Created by Jennifer Wasson on 7/16/17.
//  Copyright © 2017 Jennifer Wasson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var model = Model()
    
    @IBAction func StartButton(_ sender: UIButton) {
        
      
       // Model.addtoUserDefaults(gradepoints: 3, classname: "Chemistry", ExpectedGrade: "A-", hours: 4)
    //UserDefaults.standard.removePersistentDomain(forName: Bundle.main.bundleIdentifier!)
        Model.LoadGradesArray()
        print ("Start Button pressed")
        //self.performSegue(withIdentifier: "SecondViewSegue", sender: self)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

