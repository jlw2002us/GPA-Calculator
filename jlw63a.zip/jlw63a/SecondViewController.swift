//
//  SecondViewController.swift
//  button
//
//  Created by Jennifer Wasson on 7/19/17.
//  Copyright © 2017 Jennifer Wasson. All rights reserved.
//

import Foundation

import UIKit

class SecondViewController:  UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
   
    
    public var model =  Model()
    var count = 0
    
   
    @IBAction func nextButton(_ sender: Any) {
        
        if (GPALabel.text! != "0.0") && (hoursLabel.text! != "0.0"){
            SecondViewController.SubstituteBool = true
        }
    }
   
    static var SubstituteBool = false
    
    
    
    
    @IBOutlet weak var PickerView1: UIPickerView!
   
    
    @IBOutlet weak var GPALabel: UILabel!
   
    @IBOutlet weak var subView: UIView!
    
    @IBOutlet weak var hoursLabel: UILabel!
    
    
    @IBOutlet weak var PickerView2: UIPickerView!
    
    let choices2 = ["0.1","0.2","0.3","0.4","0.5","0.6","0.7","0.8","0.9","1.0","1.1","1.2","1.3","1.4","1.5","1.6","1.7","1.8","1.9","2.0","2.1","2.2","2.3","2.4","2.5","2.6","2.7","2.8","2.9","3.0","3.1","3.2","3.3","3.4","3.5","3.6","3.7","3.8","3.9","4.0"]
                    
    
    let choices: [String] = (1...90).map {  String($0)}
    
    
    
    
    
    @IBOutlet weak var subView2: UIView!
   
    @IBAction func GPAButton(_ sender: UIButton) {
        subView2.isHidden = false
        
    }
    
   
    @IBAction func hoursButton(_ sender: Any) {
        subView.isHidden = false
    }
   
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
     func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        
        if pickerView.tag == 1 {
            return choices[row]}
        else if row  <  40 {
            return choices2[row]
        }
        return ""
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView.tag == 1{
            return choices.count}
        else{
        return choices2.count
        }
    }
    
   
    
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let label = (view as? UILabel) ?? UILabel()
        label.font = UIFont(name: "Gils Sans", size: 15)
        
        //label.textColor = .blue
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 15)
        label.text = ""
     if pickerView.tag == 1{
            label.text = choices[row]}
        else if row < 40 {
        
            label.text = choices2[row]
       }
        
        return label
        
   }
    
    
    
    
    
    
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
      
        
        if pickerView.tag  ==  1 {
        
        
        let hourstaken = Double(choices[row])
            print(hourstaken!)
            hoursLabel.text = choices[row]
        Model.hoursTaken = hourstaken!
        
        
            print(Model.hoursTaken)
        }
        else if row < 40 {
            let currentGPA = Double(choices2[row])
            
            Model.currentGPA = currentGPA!
            print(Model.currentGPA)
           GPALabel.text = choices2[row]
            
        }
        count = 1
        subView.isHidden = true
        subView2.isHidden = true
        
        
       
    }
    
   // override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       // if segue.identifier == "thirdViewSegue"{
          //  print("here")
           // if let nextScene = segue.destination as? ThirdViewController{
              //  print("ther")
               // nextScene.model = self.model
           // }
            
      //  }
   // }
    
    
    override func viewDidLoad() {
        
        GPALabel.text = String(Model.currentGPA)
        hoursLabel.text = String(Model.hoursTaken)
        super.viewDidLoad()
         subView.isHidden = true
         subView2.isHidden = true
       
        // Do any additional setup after loading the view, typically from a nib.
    }
   
    
 
}
